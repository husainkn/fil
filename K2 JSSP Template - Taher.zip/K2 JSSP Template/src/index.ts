import '@k2oss/k2-broker-core';

import {so_SPLibraryListName,onexecuteSPLibraryListName} from "./so_SPLibraryListName";



metadata = {
    systemName: "com.k2.SP-Libraries",
    displayName: "JSSP - SP Libraries",
    description: "Static schema Common Libraries ",
    "configuration": {
        "SPURL": {
            "displayName": "SPURL",
            "type": "string",
            "value": "https://[DOMAIN]/_api/",
            "required": true
        },
        
        "DEBUG": {
            "displayName": "DEBUG",
            "type": "boolean",
            "value": true
        }
    }
};

ondescribe = async function ({ configuration }): Promise<void> {
    console.log("ondescribe");
    postSchema({
        objects: {   
            so_SPLibraryListName
        }
    });
}

onexecute = async function ({ objectName, methodName, parameters, properties, configuration}): Promise<void> {
    switch (objectName) {
    
        case "so_SPLibraryListName": await onexecuteSPLibraryListName(methodName, properties, parameters, configuration); break;
        default: throw new Error("The object " + objectName + " is not supported.");
    }
}