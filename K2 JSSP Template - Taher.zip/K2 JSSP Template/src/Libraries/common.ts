import "@k2oss/k2-broker-core";


export function Getxhr(configuration : SingleRecord,methotType: string, url: string, callback: (n: any) => any): Promise<void> {
    return new Promise<void>((resolve, reject) => {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            try {
                if (xhr.readyState !== 4) return;
                if (xhr.status !== 200) throw new Error("Failed with status " + xhr.status + " statustext: " + xhr.statusText);
                
                callback(xhr);
                resolve();
            } catch (e) {
                console.log("executexhr error: " + e + ' xhr.responseText: ' + xhr.responseText);
                reject(e);
            }
        };
        xhr.onerror = function () {
            Error("Failed with status " + xhr.status);
            
            reject(new Error("Failed with status " + xhr.status));
        }

        console.log("executexhr " + methotType + " url: " + url);
        xhr.withCredentials = true;
        xhr.open(methotType, url);
        xhr.setRequestHeader('Accept', '*/*');
        xhr.setRequestHeader('Accept-Encoding', 'gzip, deflate, br');
        
        xhr.send();
    });
}

export function DELETExhr(configuration : SingleRecord,methotType: string, url: string, callback: (n: any) => any): Promise<void> {
    return new Promise<void>((resolve, reject) => {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            try {
                if (xhr.readyState !== 4) return;
                if (xhr.status !== 200 && xhr.status !== 400 && xhr.status !== 404) throw new Error("Failed with status " + xhr.status + " statustext: " + xhr.statusText);
                
                callback(xhr);
                resolve();
            } catch (e) {
                console.log("executexhr error: " + e + ' xhr.responseText: ' + xhr.responseText);
                reject(e);
            }
        };
        xhr.onerror = function () {
            Error("Failed with status " + xhr.status);
          
            reject(new Error("Failed with status " + xhr.status));
        }

        console.log("executexhr " + methotType + " url: " + url);
        xhr.withCredentials = true;
        xhr.open(methotType, url);
        xhr.setRequestHeader('Accept', '*/*');
        // xhr.setRequestHeader('Accept-Encoding', 'gzip, deflate, br');
        // xhr.setRequestHeader('content-encoding', 'gzip, deflate, br');
       
        xhr.send();
    });
}

export function POSTxhr(configuration : SingleRecord,methotType: string, url: string, data:any, callback: (n: any) => any): Promise<void> {
    return new Promise<void>((resolve, reject) => {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            try {
                if (xhr.readyState !== 4) return;
                if (xhr.status !== 200 && xhr.status !== 201 && xhr.status !== 204) throw new Error("Failed with status " + xhr.status + " statustext: " + xhr.statusText);
                
               console.log("executexhr xhr responseText: " + xhr.responseText);
                callback(xhr);
                resolve();
            } catch (e) {
                console.log("executexhr error: " + e + ' xhr.responseText: ' + xhr.responseText);
                reject(e);
            }
        };
        xhr.onerror = function () {
            Error("Failed with status " + xhr.status);
          
            reject(new Error("Failed with status " + xhr.status));
        }

        console.log("executexhr " + methotType + " url: " + url);
        xhr.open(methotType, url);
        xhr.setRequestHeader('Accept', '*/*');
        xhr.setRequestHeader('Accept-Encoding', 'gzip, deflate, br');
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.withCredentials = true;    
        if(data !== null && data !== undefined)
        {
            console.log("Request Data "+data);
            xhr.send(data);

        }
        else
        {
            xhr.send();
        }
    });
}

