import "@k2oss/k2-broker-core";
import {  Getxhr, POSTxhr } from "./Libraries/common";

export var so_SPLibraryListName = {
    displayName: "SPLibraryListName",
    description: " SPLibraryListName",
    properties: {     
        
        
        "propertName": {
            "displayName": "propertName",
            "type": "string",
            "data": {
                "keyword": ""
            },
            "description": "propertName Value"
        }
    },
    methods: {
        "GetList": {
            "displayName": "GetList",
            "type": "list",
            "inputs": ["propertName"],
            "requiredInputs": ["propertName"],
            "parameters": {
                "$filter": {
                "displayName": "$filter",
                "type": "string",
                "data": {
                    "in": "query"
                }
            },
            "$Skip": {
                "displayName": "$Skip",
                "type": "string",
                "data": {
                    "in": "query"
                }
            }},
            "requiredParameters": ["$filter"],
            "outputs": ["propertName"]     
        }

}
       
} as ServiceObject;

export async function onexecuteSPLibraryListName(methodName: string, properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    switch (methodName) {
        case "GetList": await onexecuteGetList(properties, parameters, configuration); break;
        default: throw new Error("The method " + methodName + " is not supported.");
    }
}

export async function onexecuteGetList(properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord){

    return  new Promise<void>(async (resolve, reject) => { 
    try {  
    let filter = parameters["$filter"]as string;
    let Skip = parameters["$Skip"] as string;
    let url = configuration["ServiceURL"] + `/SPListName?$filter=${filter}`
    if(Skip != "" && Skip != undefined)
    {
         url= url + `&$skiptoken=${Skip}`
    }
    let xhr = new XMLHttpRequest();
    let responseCallBack = (response) =>
           {
               xhr = response;            
           }
    await Getxhr(configuration,"GET", url,responseCallBack); 
    if (xhr.status == 200) 
    {
        console.log("Response   : " + xhr.responseText);
        var responseData ={}
        var returnArray =[]
        if(JSON.parse(xhr.responseText) != undefined)
        {    
            var obj = JSON.parse(xhr.responseText);
            if(obj.value.length!= 0)
            {
                obj.value.forEach(e => {
                   
                    responseData = {

                        "propertName":e.propertName,
                      
                    }
                    returnArray.push(responseData);
                });
               
            }           
        }      
    postResult(returnArray) 
    }  
    resolve();            
    }catch (e) {
       
        reject(e);
         }    
    });    
 }
