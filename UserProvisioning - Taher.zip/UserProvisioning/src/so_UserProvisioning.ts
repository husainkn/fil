import "@k2oss/k2-broker-core";
import { ConsoleError,ConsoleLog, POSTxhr,Getxhr,DELETExhr } from "./common";

export var UserProvisioning = {
    displayName: "Guest User Provisioning",
    description: "Provision Guest Users",
    properties: {     
        "mail": {
            "displayName": "Email",
            "type": "string",
            "description": "mail"
        },
        "firstName": {
            "displayName": "First Name",
            "type": "string",
            "description": "First Name"
        },
        "lastName": {
            "displayName": "Last Name",
            "type": "string",
            "description": "Last Name"
        },
        "welcomeMessage": {
            "displayName": "Welcome Message",
            "type": "string",
        },
        "objectId": {
            "displayName": "ObjectId",
            "type": "string",
            "description": "objectId"
        },
        "groupId": {
            "displayName": "GroupId",
            "type": "string",
            "description": "groupId"
        },
        "GroupIdArray": {
            "displayName": "GroupIdArray",
            "type": "string",
            "description": "GroupIdArray",
            "extendedType": "k2.com/2019/memo"
        } ,
        "message": {
            "displayName": "Message",
            "type": "string",
            "description": "message"
        },  
        "search": {
            "displayName": "Search",
            "type": "string",
            "description": "Search"
        },   
        "displayName": {
            "displayName": "Display Name",
            "type": "string",
            "description": "Display Name"
        },   
        "id": {
            "displayName": "objectId",
            "type": "string",
            "description": "objectId"
        },  
        "userPrincipalName": {
            "displayName": "User Principal Name",
            "type": "string",
            "description": "User Principal Name"
        },   
        "jobTitle": {
            "displayName": "SAP Id",
            "type": "string",
            "description": "SAP Id"
        },  
        "SAPId": {
            "displayName": "SAP Id",
            "type": "string",
            "description": "SAP Id"
        }, 
    },
    methods: {             
            "ProvisionGuestUser": {
                "displayName": "Provision Guest User",
                "type":"execute",
                "inputs": ["mail","firstName","lastName","welcomeMessage","GroupIdArray","SAPId"],
                "requiredInputs": ["mail","firstName","lastName","welcomeMessage","GroupIdArray","SAPId"],
                "requiredParameters": [],
                "outputs": ["objectId","message"]
            },  
            "ResendInvitation": {
                "displayName": "Resend Invitation",
                "type":"execute",
                "inputs": ["mail","welcomeMessage"],
                "requiredInputs": ["mail"],
                "requiredParameters": [],
                "outputs": ["objectId"]
            },     
            "AddUserToGroups": {
                "displayName": "Add User To Groups",
                "type":"execute",
                "inputs": ["objectId","GroupIdArray"],
                "requiredInputs": ["objectId","GroupIdArray"],
                "requiredParameters": [],
                "outputs": ["message"]
            },        
            "GetUsers": {
                "displayName": "Get Users",
                "type":"list",
                "inputs": ["search"],
                "requiredInputs": [""],
                "requiredParameters": [],
                "outputs": ["displayName","mail","id","userPrincipalName","jobTitle"]
            },          
            "GetGroupsForUser": {
                "displayName": "Get Groups for User",
                "type":"list",
                "inputs": ["objectId"],
                "requiredInputs": ["objectId"],
                "requiredParameters": [],
                "outputs": ["groupId"]
            },
            "GetUsersForGroup": {
                "displayName": "Get Users For Group",
                "type":"list",
                "inputs": ["groupId"],
                "requiredInputs": ["groupId"],
                "requiredParameters": [],
                "outputs": ["displayName","mail","id","userPrincipalName"]
            },
            "RemoveUserFromGroup": {
                "displayName": "Remove User From Group",
                "type":"execute",
                "inputs": ["objectId","groupId"],
                "requiredInputs": ["objectId","groupId"],
                "requiredParameters": [],
                "outputs": ["message"]
            },             
            "DeleteGuestUser": {
                "displayName": "Delete Guest User",
                "type":"execute",
                "inputs": ["objectId"],
                "requiredInputs": ["objectId"],
                "parameters": {},
                "requiredParameters": [],
                "outputs": ["message"]
            },             
            "UpdateSAPId": {
                "displayName": "Update SAP Id",
                "type":"execute",
                "inputs": ["objectId","SAPId"],
                "requiredInputs": ["objectId","SAPId"],
                "parameters": {},
                "requiredParameters": [],
                "outputs": []
            },                  
            "PackGroupIdArray": {
                "displayName": "Build Group Id Array",
                "type":"execute",
                "inputs": ["objectId"],
                "requiredInputs": ["objectId"],                
                "parameters": {
                    "GroupId.String.Param": {
                    "displayName": "JSON Group Object Array String",
                    "description": "JSON String",
                    "type":"string",
                    "extendedType": "k2.com/2019/memo"}
                                },
                "requiredParameters": ["GroupIdArray"],
                "outputs": ["GroupIdArray"]
            } 

        }
       
} as ServiceObject;

export async function onexecuteUserProvisioning(methodName: string, properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    switch (methodName) {
        case "ProvisionGuestUser": await onexecuteProvisionGuestUser(properties, parameters, configuration); break;
        case "GetUsers": await onexecuteGetUsers(properties,configuration); break;        
        case "GetUsersForGroup": await onexecuteGetUsersForGroup(properties,configuration); break;
        case "GetGroupsForUser": await onexecuteGetGroupForUser(properties,configuration); break;         
        case "ResendInvitation": await onexecuteSendInvitation(properties, configuration); break;
        case "AddUserToGroups": await onexecuteAddUserToGroups(properties, configuration); break;
        case "RemoveUserFromGroup": await onexecuteRemoveUserFromGroup(properties, configuration); break;
        case "DeleteGuestUser": await onexecuteDeleteGuestUser(properties, parameters, configuration); break;
        case "UpdateSAPId":await updateSAPId(properties, configuration); break;
        case "PackGroupIdArray": await onexecuteGroupPackJSONObjectArray(parameters, properties, configuration);break;
        default: throw new Error(`The method ${methodName} is not supported.`);
    }
}

//Create a guest user and add them to the relevant groups.
export async function onexecuteProvisionGuestUser(properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    return  new Promise<void>(async (resolve, reject) => {
        try {          
        
                let invitationResponse:any = await sendInvitation(properties,configuration);

                if(invitationResponse.status==="error")
                {
                    await postResult({"message":invitationResponse.message})
                    resolve();
                    return;
                }
                await addUserToGroups(configuration,properties,invitationResponse.objectId);

                await updateSAPIdInternal(configuration,properties,invitationResponse.objectId);

                await postResult({"message":"success","objectId":invitationResponse.objectId})
                resolve();
                } 
        catch (e) {
                ConsoleError(`${e.message} \rError stack:${e.stack}`,"UserProvisionig.onexecuteProvisionGuestUser",configuration);
                reject(e);
            }    
        });
}

//Get all users from AAD
export async function onexecuteGetGroupForUser(properties: SingleRecord, configuration: SingleRecord): Promise<void> {
    return  new Promise<void>(async (resolve, reject) => {
        try {          
            let responseObj:any; 
            var xhr = new XMLHttpRequest();
            let responseCallBack = (xhrObj) =>
                {
                    xhr =xhrObj;
                    if(xhr.status === 200)
                    {
                        let groups:any = [];
                        responseObj = JSON.parse(xhr.responseText);
                        responseObj.value.forEach(groupId => {
                            groups.push({"groupId":groupId});
                        });
                        console.log(`Groups For User:${groups}`);
                        postResult(groups);
                        resolve();
                        return;
                    }      
                    if(xhr.status === 400)
                    {
                        ConsoleError(responseObj.error.message,"UserProvisionig.onexecuteGetGroupForUser",configuration);
                        resolve();
                    }     
                }
            let url:string;
            let filter:string='';
                   
            url = `${configuration["MSGraphAPIURL"]}users/${properties["objectId"]}/getMemberGroups`; 
            let data:any={"securityEnabledOnly":true};
            await POSTxhr(configuration,"POST", url, JSON.stringify(data), responseCallBack);
                } 
        catch (e) {
                ConsoleError(`${e.message} \rError stack:${e.stack}`,"UserProvisionig.onexecuteGetGroupForUser",configuration);
                reject(e);
            }    
        });
}

//Get all users from AAD
export async function onexecuteGetUsersForGroup(properties: SingleRecord, configuration: SingleRecord): Promise<void> {
    return  new Promise<void>(async (resolve, reject) => {
        try {          
            let responseObj:any; 
            var xhr = new XMLHttpRequest();
            let responseCallBack = (xhrObj) =>
                {
                    xhr =xhrObj;
                    if(xhr.status === 200)
                    {
                        responseObj = JSON.parse(xhr.responseText);
                        postResult(responseObj.value);
                        resolve();
                        return;
                    }      
                    if(xhr.status === 400)
                    {
                        ConsoleError(responseObj.error.message,"UserProvisionig.onexecuteGetUsersForGroup",configuration);
                        resolve();
                    }     
                }
            let url:string;
            let filter:string='';
    
            url = `${configuration["MSGraphAPIURL"]}groups/${properties["groupId"]}/members?$count=true`;                

            await Getxhr(configuration,"GET", url, responseCallBack);
                } 
        catch (e) {
                ConsoleError(`${e.message} \rError stack:${e.stack}`,"UserProvisionig.onexecuteGetUsersForGroup",configuration);
                reject(e);
            }    
        });
}

//Get all users from AAD
export async function onexecuteGetUsers(properties: SingleRecord, configuration: SingleRecord): Promise<void> {
    return  new Promise<void>(async (resolve, reject) => {
        try {          
            let responseObj:any; 
            var xhr = new XMLHttpRequest();
            let responseCallBack = (xhrObj) =>
                {
                    xhr =xhrObj;
                    if(xhr.status === 200)
                    {
                        responseObj = JSON.parse(xhr.responseText);
                        postResult(responseObj.value);
                        resolve();
                        return;
                    }      
                    if(xhr.status === 400)
                    {
                        ConsoleError(responseObj.error.message,"UserProvisionig.onexecuteGetUsers",configuration);
                        resolve();
                    }     
                }
            let url:string;
            let filter:string='';
            if(properties["search"] as string!=='' && properties["search"] !== undefined && properties["search"]!==null)
            {
                filter = `startsWith(mail,'${properties["search"] as string}')`;
                url = `${configuration["MSGraphAPIURL"]}users/?$filter=${filter}`;    
            }
            else
            {
                //Get all users if no filter is specified
                url = `${configuration["MSGraphAPIURL"]}users`;   
            }

            await Getxhr(configuration,"GET", url, responseCallBack);
                } 
        catch (e) {
                ConsoleError(`${e.message} \rError stack:${e.stack}`,"UserProvisionig.onexecuteGetUsers",configuration);
                reject(e);
            }    
        });
}

//Send an invitation mail to the address supplied
async function onexecuteSendInvitation(properties: SingleRecord, configuration: SingleRecord) {
    return  new Promise<void>(async (resolve, reject) => {
        try {   
                let response:any = await sendInvitation(properties,configuration);
                if(response.status==="success")
                {
                await postResult({"message":"success","objectId":response.objectId})
                }
                resolve();
            } 
        catch (e) {
                ConsoleError(`${e.message} \rError stack:${e.stack}`,"UserProvisionig.onexecuteSendInvitation",configuration);
                reject(e);
                }    
    });
}

//Add a user to the designated groups
async function onexecuteAddUserToGroups(properties: SingleRecord, configuration: SingleRecord) {
    return  new Promise<void>(async (resolve, reject) => {
        try {   
                await addUserToGroups(configuration,properties,properties["objectId"] as string);
                resolve();
                postResult({"message":"success"})
        }
        catch (e) {
                ConsoleError(`${e.message} \rError stack:${e.stack}`,"UserProvisionig.onexecuteAddUserToGroups",configuration);
                reject(e);
                }    
    });
}

//Delete a user from the tenant.
export async function onexecuteDeleteGuestUser(properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    return new Promise<void>(async(resolve, reject) => {
        try {    
            
            let userType = await getUserType(properties,configuration);

            if(userType!=="Guest")
            {
                ConsoleLog("Only guest user accounts can be deleted","UserProvisioning.onExecuteDeleteGuestUser",configuration );
                console.log(`UserType:${userType} - Only guest user accounts can be deleted`);
                postResult({"message":`"UserType:${userType} - Only guest user accounts can be deleted"`});
                resolve();
                return;
            }

            var xhr = new XMLHttpRequest();
            let responseCallBack = (response) =>
                {
                    xhr = response;            
                }

            var url = `${configuration["MSGraphAPIURL"]}users/${properties["objectId"]}`;
            await DELETExhr(configuration,"DELETE", url, responseCallBack);
            if(xhr.status===204)
            {
                postResult({"message":"success"});
            }
            else
            {
                postResult({"message":JSON.parse(xhr.responseText).error.message});

            }
            resolve();

        } catch (e) {
            console.log(`Error:${e.message} \rError stack:${e.stack}`);
            reject(e);
        }   
    });
}

//Add a user to the designated groups
async function onexecuteRemoveUserFromGroup(properties: SingleRecord, configuration: SingleRecord) {
    return new Promise<void>(async(resolve, reject) => {
        try {    
            
            let userType = await getUserType(properties,configuration);

            if(userType!=="Guest")
            {
                ConsoleLog("Only guest user accounts can be removed from groups","UserProvisioning.onexecuteRemoveUserFromGroup",configuration );
                console.log(`UserType:${userType} - Only guest user accounts can be removed from groups`);
                postResult({"message":`"UserType:${userType} - Only guest user accounts can be removed from groups"`});
                resolve();
                return;
            }

            var xhr = new XMLHttpRequest();
            let responseCallBack = (response) =>
                {
                    xhr = response;            
                }

            var url = `${configuration["MSGraphAPIURL"]}groups/${properties["groupId"]}/members/${properties["objectId"]}/$ref`;
            await DELETExhr(configuration,"DELETE", url, responseCallBack);
            if(xhr.status===204)
            {
                postResult({"message":"success"});
            }
            else
            {
                postResult({"message":JSON.parse(xhr.responseText).error.message});

            }
            resolve();

        } catch (e) {
            ConsoleError(`${e.message} \rError stack:${e.stack}`,"UserProvisionig.onexecuteProvisionGuestUser",configuration);
            reject(e);
        }   
    });
}

//Build up an array of GroupIds
function onexecuteGroupPackJSONObjectArray(parameters: SingleRecord, properties: SingleRecord, configuration: SingleRecord): Promise < void > {
    return new Promise < void > ((resolve, reject) => {
        try {
            // declare array
            var tableData = [];

            tableData.push((properties));

            if(parameters["GroupId.String.Param"]===undefined || parameters["GroupId.String.Param"] === "")
            {
                parameters["GroupId.String.Param"] = "[]";
            }
            let varArrayObj = [] = parameters["GroupId.String.Param"]===undefined?{"GroupId.String.Param":[]}:JSON.parse(parameters["GroupId.String.Param"] as string);
            
            if (varArrayObj != undefined) {
                varArrayObj.forEach(e => {
                    tableData.push(e);

                });
            }
            let obj = {
                "GroupIdArray": JSON.stringify(tableData)
            }
            postResult(obj);
            resolve();
        } catch (error) {
            ConsoleError(error, "onexecuteGroupPackJSONObjectArray", configuration);
            reject(error);
        }
    });
}

//Send an invitation mail to the address supplied
async function sendInvitation(properties: SingleRecord, configuration: SingleRecord) {
    return  new Promise<any>(async (resolve, reject) => {
        try 
        {
            if(!isDomainAllowed(configuration["allowedDomains"] as string,properties["mail"] as string))
            {
                resolve({"status":"error","message":`Invalid domain, users from the domain ${(properties["mail"] as string).split("@")[1]} cannot be invited`});
                return;
            }

            let responseObj:any; 
            var xhr = new XMLHttpRequest();
            let responseCallBack = (xhrObj) =>
                {
                    xhr =xhrObj;
                    if(xhr.responseText !== undefined)
                    {
                        responseObj = JSON.parse(xhr.responseText);
                    }      
                    if(xhr.status === 400)
                    {
                        ConsoleError(responseObj.error.message,"UserProvisionig.onexecuteProvisionGuestUser",configuration);
                        resolve({"status":"error","message":responseObj.error.message});
                    }           
                    else
                        {
                        console.log(`Invitation Response:${JSON.stringify(responseObj)}`);
                        resolve({"status":"success","objectId":responseObj.invitedUser.id});
                    }
                    return;
                }
            
            let invitationBody = CreateInvitationBody(configuration,properties);
                
            var url = `${configuration["MSGraphAPIURL"]}invitations`;

            await POSTxhr(configuration,"POST", url,JSON.stringify(invitationBody), responseCallBack);
         } 
        catch (e) {
                reject(e);
        }  
    });
}

//Check that the mail address is in the list of allowed domains.
function isDomainAllowed(allowedDomainsString:string,mail:string):boolean
{    
    if(allowedDomainsString==='')
    {
        //No domains are listed
        return true;
    }
    let allowedDomains=[]=allowedDomainsString.split(",");
    let mailDomain:string = mail.split("@")[1];

    if(allowedDomains.find(element=>element === mailDomain))
    {
        return true;
    }
    return false;
}

//Get the user type
async function getUserType(properties: SingleRecord, configuration: SingleRecord) {
    return  new Promise<string>(async (resolve, reject) => {
        try 
        {
            let responseObj:any; 
            var xhr = new XMLHttpRequest();
            let responseCallBack = (xhrObj) =>
                {
                    xhr =xhrObj;
                    if(xhr.responseText !== undefined)
                    {
                        responseObj = JSON.parse(xhr.responseText);
                    }      
                    if(xhr.status === 400)
                    {
                        ConsoleError(responseObj.error.message,"UserProvisionig.getUserType",configuration);
                    }        
                    if(xhr.status===404) 
                    {
                        resolve("NotFound")
                    }  
                }
                
            var url = `${configuration["MSGraphAPIURL"]}users/${properties["objectId"]}?$select=userType`;

            await Getxhr(configuration,"GET", url, responseCallBack);
            
            console.log(`Invitation Response:${JSON.stringify(responseObj)}`);
            resolve(responseObj.userType);
        } catch (e) {
                reject(e);
                }    
    });
}

//Create the invitaiton request body
function CreateInvitationBody(configuration:SingleRecord,properties:SingleRecord):any
{
    let invitation:any;
    if(properties["firstName"]!==undefined && properties["lastName"]!==undefined)
        {
            invitation = {
                "invitedUserEmailAddress": properties["mail"],
                "inviteRedirectUrl": `${configuration["K2BaseUrl"]}Runtime/Runtime/Form/TSDE.Form.LandingPage/`,
                "sendInvitationMessage": true,
                "invitedUserDisplayName": `${properties["firstName"]} ${properties["lastName"]}`,
                "invitedUserMessageInfo": {
                "customizedMessageBody": properties["welcomeMessage"]
                }
            }
        }    
    else
        {
            invitation = {
                "invitedUserEmailAddress": properties["mail"],
                "inviteRedirectUrl": `${configuration["K2BaseUrl"]}Runtime/Runtime/Form/TSDE.Form.LandingPage/`,
                "sendInvitationMessage": true,
                "invitedUserMessageInfo": {
                "customizedMessageBody": properties["welcomeMessage"]
                }
            }
        }
    return invitation;
}

//Add the user to the requested groups.
async function addUserToGroups(configuration:SingleRecord,properties:SingleRecord,userId:string)
{
    return new Promise<void>(async(resolve, reject) => {
        try {    
                let responseObj:any; 
                var xhr = new XMLHttpRequest();
                
                let responseCallBack = (xhrObj) =>
                    {
                        xhr =xhrObj;
                        if(xhr.responseText !== undefined && xhr.responseText !="")
                        {
                            responseObj = JSON.parse(xhr.responseText);
                            console.log(xhr.responseText);                            
                        }      
                        if(xhr.status === 400)
                        {
                            ConsoleError(responseObj.error.message,"UserProvisionig.addUserToGroups",configuration);
                        }        
                    }
        
                let batchBody:any = buildGroupBatch(configuration,JSON.parse(properties["GroupIdArray"] as string),userId);
                var url = `${configuration["MSGraphAPIURL"]}$batch`;
                await POSTxhr(configuration,"POST", url,JSON.stringify(batchBody), responseCallBack);                
                console.log(xhr.responseText);  
                resolve();
            } 
        catch (e) {
            reject(e);
        }    
    });

}

//Update the users SAPId, JobTitle field has been used for this purpose.
async function updateSAPId(properties:SingleRecord, configuration:SingleRecord)
{
    return new Promise<void>(async(resolve, reject) => {
        try {    
                let responseObj:any; 
                var xhr = new XMLHttpRequest();
                
                let responseCallBack = (xhrObj) =>
                    {
                        xhr =xhrObj;
                        if(xhr.responseText !== undefined && xhr.responseText !="")
                        {
                            responseObj = JSON.parse(xhr.responseText);
                            console.log(xhr.responseText);                            
                        }      
                        if(xhr.status === 400)
                        {
                            ConsoleError(responseObj.error.message,"UserProvisionig.updateSAPId",configuration);
                        }        
                    }
        
                var url = `${configuration["MSGraphAPIURL"]}/users/${properties["objectId"]}`;
                console.log(`Url updateSAPId:${url}`);
                var body = {jobTitle:properties["SAPId"]};
                await POSTxhr(configuration,"PATCH", url,JSON.stringify(body), responseCallBack);                
                console.log(xhr.responseText);  
                resolve();
            } 
        catch (e) {
            reject(e);
        }    
    });

}

//Update the users SAPId, JobTitle field has been used for this purpose.
async function updateSAPIdInternal(configuration:SingleRecord, properties:SingleRecord,userId:String)
{
    return new Promise<void>(async(resolve, reject) => {
        try {    
                let responseObj:any; 
                var xhr = new XMLHttpRequest();
                
                let responseCallBack = (xhrObj) =>
                    {
                        xhr =xhrObj;
                        if(xhr.responseText !== undefined && xhr.responseText !="")
                        {
                            responseObj = JSON.parse(xhr.responseText);
                            console.log(xhr.responseText);                            
                        }      
                        if(xhr.status === 400)
                        {
                            ConsoleError(responseObj.error.message,"UserProvisionig.updateSAPId",configuration);
                        }        
                    }
        
                var url = `${configuration["MSGraphAPIURL"]}/users/${userId}`;
                var body = {jobTitle:properties["SAPId"]}
                await POSTxhr(configuration,"PATCH", url,JSON.stringify(body), responseCallBack);                
                console.log(xhr.responseText);  
                resolve();
            } 
        catch (e) {
            reject(e);
        }    
    });

}

function buildGroupBatch(configuration:SingleRecord,groupIdArray:any,userId:string):string
{
    var batch:any={"requests":[]};
    
    groupIdArray.forEach(async group => 
        {                                               
            let batchRequestItem:any = 
            {
                "id": group.objectId,
                "url": `/groups/${group.objectId}/members/$ref`,
                "method": "POST",
                "body": 
                    {
                    "@odata.id": `https://graph.microsoft.com/v1.0/directoryObjects/${userId}`
                    },
                "headers": 
                    {
                        "Content-Type": "application/json"
                    }
            }
        batch.requests.push(batchRequestItem);
    }
    );
    return batch;
}

let Base64 = {

    // private property
    _keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    
    // public method for encoding
    encode : function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
    
        input = Base64._utf8_encode(input);
    
        while (i < input.length) {
    
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
    
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
    
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
    
            output = output +
            this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
            this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
    
        }
    
        return output;
    },
    
    // public method for decoding
    decode : function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
    
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
    
        while (i < input.length) {
    
            enc1 = this._keyStr.indexOf(input.charAt(i++));
            enc2 = this._keyStr.indexOf(input.charAt(i++));
            enc3 = this._keyStr.indexOf(input.charAt(i++));
            enc4 = this._keyStr.indexOf(input.charAt(i++));
    
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
    
            output = output + String.fromCharCode(chr1);
    
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
    
        }
    
        output = Base64._utf8_decode(output);
    
        return output;
    
    },
    
    // private method for UTF-8 encoding
    _utf8_encode : function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";
    
        for (var n = 0; n < string.length; n++) {
    
            var c = string.charCodeAt(n);
    
            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
    
        }
    
        return utftext;
    },
    
    // private method for UTF-8 decoding
    _utf8_decode : function (utftext) {
        var string = "";
        var i = 0;
        var c = 0, c1 = 0, c2 = 0, c3 = 0;
    
        while ( i < utftext.length ) {
    
            c = utftext.charCodeAt(i);
    
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
    
        }
    
        return string;
    }
}

function getBase64FromContent(content: string)
{
    var base64 = "";

    var split1 = content.split("<content>")[1];
    base64 = split1.split("</content>")[0];

    return base64;
}