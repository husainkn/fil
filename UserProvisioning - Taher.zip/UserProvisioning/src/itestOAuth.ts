// This value is obfuscated on purpose. Replace with a valid OAuth token to run ITest
export var OAuthToken = "XXX";