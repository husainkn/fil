import '@k2oss/k2-broker-core';
import { onexecuteUserProvisioning, UserProvisioning } from "./so_UserProvisioning";


metadata = {
    systemName: "com.k2.MS-Graph-User-Provisioning",
    displayName: "JSSP - User Provisioning Libraries",
    description: "Static schema User Provisioning Libraries",
    "configuration": {
        "MSGraphAPIURL": {
            "displayName": "MS Graph API URL",
            "type": "string",
            "value": "https://graph.microsoft.com/v1.0/",
            "required": true
            
        },
        "K2BaseUrl": {
            "displayName": "K2 Base URL",
            "type": "string",
            "value": "https://[VanityName].onk2.com/",
            "required": true
        },
        "LoggingBaseUrl": {
            "displayName": ":Logging Base Url",
            "type": "string",
            "value": "https://[DOMAIN]/api/",
            "required": true
        },
        "APIKey": {
            "displayName": "API Key",
            "type": "string",
            "value": ""
        },
        "APIKeyRequired": {
            "displayName": "APIKeyRequired",
            "type": "boolean",
            "value": false
        },
        "DEBUG": {
            "displayName": "DEBUG",
            "type": "boolean",
            "value": true
        },
        "allowedDomains": {
            "displayName": "Allowed Domains",
            "type": "string",
            "value": "nintex.com,k2.com"
        }
    }
};

ondescribe = async function ({ configuration }): Promise<void> {
    console.log("ondescribe");
    postSchema({
        objects: {   
            UserProvisioning
        }
    });
}

onexecute = async function ({ objectName, methodName, parameters, properties, configuration}): Promise<void> {
    switch (objectName) {
            case "UserProvisioning":await onexecuteUserProvisioning(methodName, properties, parameters, configuration); break;
        default: throw new Error("The object " + objectName + " is not supported.");
    }
}