import "@k2oss/k2-broker-core";
import { Log } from "./KibanaLogging";

export function Getxhr(configuration : SingleRecord,methotType: string, url: string, callback: (n: any) => any): Promise<void> {
    return new Promise<void>((resolve, reject) => {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            try {
                if (xhr.readyState !== 4) return;
                if (xhr.status !== 200 && xhr.status != 404) throw new Error("Failed with status " + xhr.status + " statustext: " + xhr.statusText);
                
                callback(xhr);
                resolve();
            } catch (e) {
                console.log("executexhr error: " + e + ' xhr.responseText: ' + xhr.responseText);
                reject(e);
            }
        };
        xhr.onerror = function () {
            Error("Failed with status " + xhr.status);
            ConsoleError("executexhr onerror: Failed with status " + xhr.status,'HTTP Respnonse',configuration);
            reject(new Error("Failed with status " + xhr.status));
        }

        console.log("executexhr " + methotType + " url: " + url);
        xhr.withCredentials = true;
        xhr.open(methotType, url);
        xhr.setRequestHeader('content-type',"application/json;odata.metadata=minimal;odata.streaming=true;IEEE754Compatible=false;charset=utf-8");
        if (configuration["APIKeyRequired"] as string == "true") {
            if (configuration["APIKey"] != null || configuration["APIKey"] != "") {
                xhr.setRequestHeader("APIKey", configuration["APIKey"] as string)
            }
        }
        xhr.send();
    });
}

export function DELETExhr(configuration : SingleRecord,methotType: string, url: string, callback: (n: any) => any): Promise<void> {
    return new Promise<void>((resolve, reject) => {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            try {
                if (xhr.readyState !== 4) return;
                if (xhr.status !== 200 && xhr.status !== 400 && xhr.status !== 404 && xhr.status !=204) throw new Error("Failed with status " + xhr.status + " statustext: " + xhr.statusText);
                
                callback(xhr);
                resolve();
            } catch (e) {
                console.log("executexhr error: " + e + ' xhr.responseText: ' + xhr.responseText);
                reject(e);
            }
        };
        xhr.onerror = function () {
            Error("Failed with status " + xhr.status);
            ConsoleError("executexhr onerror: Failed with status " + xhr.status,'HTTP Response',configuration);
            reject(new Error("Failed with status " + xhr.status));
        }

        console.log("executexhr " + methotType + " url: " + url);
        xhr.withCredentials = true;
        xhr.open(methotType, url);
        xhr.setRequestHeader('Accept', '*/*');
        if (configuration["APIKeyRequired"] as string == "true") {
            if (configuration["APIKey"] != null || configuration["APIKey"] != "") {
                xhr.setRequestHeader("APIKey", configuration["APIKey"] as string)
            }
        }
        xhr.send();
    });
}

export function PATCHxhr(configuration : SingleRecord,methotType: string, url: string, data:any, callback: (n: any) => any): Promise<void> {
    return new Promise<void>((resolve, reject) => {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            try {
                if (xhr.readyState !== 4) return;
                if (xhr.status !== 200 && xhr.status !== 201 && xhr.status !== 204 && xhr.status !== 400) throw new Error("Failed with status " + xhr.status + " statustext: " + xhr.statusText);
                
                if(xhr.responseText !=="" && xhr.responseText !==undefined)
                {
                    console.log("executexhr xhr responseText: " + xhr.responseText);
                }
                callback(xhr);
                resolve();
            } catch (e) {
                console.log("executexhr error: " + e + ' xhr.responseText: ' + xhr.responseText !==""?xhr.responseText:"Empty response");
                reject(e);
            }
        };
        xhr.onerror = function () {
            Error("Failed with status " + xhr.status);
            ConsoleError("executexhr onerror: Failed with status " + xhr.status,'HTTPResponse',configuration);
            reject(new Error("Failed with status " + xhr.status));
        }

        console.log("executexhr " + methotType + " url: " + url);
        xhr.open(methotType, url);
        xhr.setRequestHeader('content-type',"application/json;odata.metadata=minimal;odata.streaming=true;IEEE754Compatible=false;charset=utf-8");
        xhr.withCredentials = true;
        if (configuration["APIKeyRequired"] as string == "true") {
            if (configuration["APIKey"] != null || configuration["APIKey"] != "") {
                xhr.setRequestHeader("APIKey", configuration["APIKey"] as string)
            }
        }
        
        if(data !== null && data !== undefined)
        {
            console.log("Request Data "+data);
            xhr.send(data);

        }
        else
        {
            xhr.send();
        }
    });
}

export function POSTxhr(configuration : SingleRecord,methotType: string, url: string, data:any, callback: (n: any) => any): Promise<void> {
    return new Promise<void>((resolve, reject) => {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            try {
                if (xhr.readyState !== 4) return;
                if (xhr.status !== 200 && xhr.status !== 201 && xhr.status !== 204 && xhr.status !== 400) throw new Error("Failed with status " + xhr.status + " statustext: " + xhr.statusText);
                
                if(xhr.responseText !=="" && xhr.responseText !==undefined)
                {
                    console.log("executexhr xhr responseText: " + xhr.responseText);
                }
                callback(xhr);
                resolve();
            } catch (e) {
                console.log("executexhr error: " + e + ' xhr.responseText: ' + xhr.responseText !==""?xhr.responseText:"Empty response");
                reject(e);
            }
        };
        xhr.onerror = function () {
            Error("Failed with status " + xhr.status);
            ConsoleError("executexhr onerror: Failed with status " + xhr.status,'HTTPResponse',configuration);
            reject(new Error("Failed with status " + xhr.status));
        }

        console.log("executexhr " + methotType + " url: " + url);
        xhr.open(methotType, url);
        xhr.setRequestHeader('content-type',"application/json;odata.metadata=minimal;odata.streaming=true;IEEE754Compatible=false;charset=utf-8");
        xhr.withCredentials = true;
        if (configuration["APIKeyRequired"] as string == "true") {
            if (configuration["APIKey"] != null || configuration["APIKey"] != "") {
                xhr.setRequestHeader("APIKey", configuration["APIKey"] as string)
            }
        }
        
        if(data !== null && data !== undefined)
        {
            console.log("Request Data "+data);
            xhr.send(data);

        }
        else
        {
            xhr.send();
        }
    });
}

export function ConsoleLog(message: string,componentExtension:string,configuration: SingleRecord) {
    if (configuration["DEBUG"] as string == "true" ) {
        Log(message,'info',componentExtension,configuration);
    }
}

export function ConsoleError(Message: string,componentExtension:string, configuration: SingleRecord) {
      Log(Message,'error',componentExtension,configuration);
}

export function unpackObject(sourceObject: any, propPrefix: string, unpackedObject: any): ExecuteResult {
    if (sourceObject.length > 0) {
        unpackedObject = sourceObject.map(x => {
            let unpackedSingleObject: any = {};
            flattenProperties(x, propPrefix, unpackedSingleObject);
            return unpackedSingleObject;
        });
    } else {
        flattenProperties(sourceObject, propPrefix, unpackedObject);
    }
    return unpackedObject;
}

export function flattenProperties(xSourceObject: any, propPrefix: string, unpackedObject: any): void {
    for (const propKey in xSourceObject) {
        if (xSourceObject.hasOwnProperty(propKey)) {
            const prop = xSourceObject[propKey];
          
            let propName = (propPrefix != "" ? propPrefix + "." : "") + propKey;
            if (typeof(prop) == "object" && prop != null && prop != undefined) {
                if (prop.length === undefined && propName.split(".").length < 1) {
                    unpackObject(prop, propName, unpackedObject);
                } else {
                    unpackedObject[propName] = JSON.stringify(xSourceObject[propKey]);
                   console.log("Latten properties "+unpackedObject[propName]+" ="+JSON.stringify(xSourceObject[propKey])+" Type= "+typeof(prop));
                }
            } else {
                unpackedObject[propName] = xSourceObject[propKey];
               
            }
        }
    }
}

export function parseInputObject(object: any, configuration: SingleRecord): any {
    for (const propKey in object) {
        if (object.hasOwnProperty(propKey)) {
            const value = object[propKey];
            try {
                if (value !== null) {
                    try {
                        if (typeof(object[propKey]) === "string") {
                            var obj = object[propKey];
                            obj = JSON.parse(value)
                            if (typeof(obj) === "object") {
                                object[propKey] = JSON.parse(value);
                            } else {
                                object[propKey] = JSON.parse('"' + object[propKey] + '"');
                            }

                        } else {
                            object[propKey] = JSON.parse(value);
                            if (typeof(object[propKey]) === "object") {
                                parseInputObject(object[propKey], configuration);
                            }
                        }
                    } catch (e) {
                        if (typeof(object[propKey]) === "string") {
                            object[propKey] = JSON.parse('"' + object[propKey] + '"');
                        } else {
                            object[propKey] = JSON.parse(value);
                        }

                        if (typeof(object[propKey]) === "object") {
                            parseInputObject(object[propKey], configuration);
                        }
                    }

                }
            } catch (error) {
                ConsoleError(error, "parseInputObject", configuration);
                object[propKey] = value;
            }
        }
    }
    return object
}