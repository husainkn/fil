import "@k2oss/k2-broker-core";



export async function Log(message:string,logtype:string,componentExtension:string,configuration: SingleRecord):Promise<any>
{
  return new Promise<void>((resolve, reject) => {

  var d = new Date(); 
  var timestamp  = (d.getTime()-d.getMilliseconds())/1000
  let url = configuration["LoggingBaseUrl"] +  'logging-proxy'
  var requestdata = {
    "componentName": "K2/JSSPUserProvisioningLibrary/"+componentExtension,
    "message": message,
    "severity": logtype,
    "timestamp": timestamp
   }
  var data  = JSON.stringify(requestdata);
   var xhr = new XMLHttpRequest();
   xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState !== 4) return;
      if (xhr.status !== 201 && xhr.status !== 200) 
      {   
        resolve();
      } 
      resolve();
   }
   catch (error) {
    reject();
  }
   };

   xhr.open("POST", url);
   xhr.withCredentials = false;
   xhr.setRequestHeader('Accept', '*/*');
   xhr.setRequestHeader('Accept-Encoding', 'gzip, deflate, br');
   xhr.setRequestHeader("Content-Type", "application/json");
   if (configuration["APIKeyRequired"] as string == "true") {
       if (configuration["APIKey"] != null || configuration["APIKey"] != "") {
           xhr.setRequestHeader("APIKey", configuration["APIKey"] as string)
       }
   }
   if(data !== null && data !== undefined)
   {
     
       xhr.send(data);

   }
   else
   {
       xhr.send();
   }

  });
}
